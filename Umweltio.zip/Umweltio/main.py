from flask import Flask, render_template, redirect, request, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import timedelta

app = Flask(__name__)
app.secret_key = "DIMONTURURURU"

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diary.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(40), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)

with app.app_context():
    db.create_all()

@app.before_request
def make_session_permanent():
    session.permanent = True
    app.permanent_session_lifetime = timedelta(days=7) 

@app.route('/')
def home():
    return render_template('index.html')
@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']  

        if User.query.filter_by(username=username).first():
            return render_template('register.html', message='Такой пользователь уже существует!')

        new_user = User(username=username, 
                        password=generate_password_hash(password, method='pbkdf2:sha256'), 
                        email=email)  
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login')) 

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            session['username'] = user.username
          
            return redirect(url_for('home'))  
        else:
            return render_template('login.html', message='Неправильное имя или пароль')
    
    return render_template('login.html')

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    if request.method == 'POST':
     session.pop('username', None)
     flash('Вы вышли из аккаунта ', 'info')  
     return redirect(url_for('home'))
    return render_template('confirm_logout.html')  
    

@app.route('/about_us')
def us():
    return render_template('about_us.html')

@app.route('/change_password', methods=['GET', 'POST'])
def change_password():
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')

        # Debugging-Ausgaben
        print(f'current_password: {current_password}')
        print(f'new_password: {new_password}')
        print(f'confirm_password: {confirm_password}')

        user = User.query.filter_by(username=session['username']).first()

        if user and current_password is not None:
            if check_password_hash(user.password, current_password):
                if new_password == confirm_password:
                    user.password = generate_password_hash(new_password)
                    db.session.commit()
                    flash('Пароль был изменён.')
                    return redirect(url_for('profile'))
                else:
                    flash('Пароли не соответствуют.')
            else:
                flash('Неправильный пароль.')
        else:
            flash('Введите ваш старый пароль.')

    return render_template('change_password.html')

@app.route('/change_email', methods=['GET', 'POST'])
def change_email():
    if request.method == 'POST':
        current_email = request.form.get('current_email')
        new_email = request.form.get('new_email')
        
        user = User.query.filter_by(email=current_email).first()
        
        if user:
            
            user.email = new_email
            db.session.commit()
            flash('Почта была изменна')
            session['email'] = new_email  
            return redirect(url_for('profile'))  
        else:
            flash('Почта не найденна.')
    
    return render_template('change_email.html')

@app.route('/change_username', methods=['GET', 'POST'])
def change_username():
    if request.method == 'POST':
        current_username = request.form.get('current_username')  
        new_username = request.form.get('new_username')         
        
        if current_username is None or new_username is None:
            flash('Заполните это поле.')  
            return render_template('change_username.html')
        
        user = User.query.filter_by(username=current_username).first()
        
        if user:
            if User.query.filter_by(username=new_username).first():
                flash('Такое имя уже существует.')
            else:
                user.username = new_username
                db.session.commit()
                flash('Имя было измененно')
                session['username'] = new_username
                return redirect(url_for('profile'))
        else:
            flash('Имя не найденно.')
    
    return render_template('change_username.html')

if __name__ == "__main__":
    app.run(debug=True)